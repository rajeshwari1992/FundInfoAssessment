﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FundInfoAssessment.Models
{
    public class TemporaryEmployee : Employee
    {
        public override double GetSalaryInfo(double basicpayvalue)
        {

            salary = 1.5 * basicpayvalue;
            return salary;
        }

         
    }
}
