﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FundInfoAssessment.Models
{
    public class PermanentEmployee : Employee
    {
        public override double GetSalaryInfo(double basicpayvalue)
        {

            salary = 2.0 * basicpayvalue;
            return salary;
        }


    }
}
