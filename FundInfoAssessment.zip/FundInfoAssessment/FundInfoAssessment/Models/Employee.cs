﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FundInfoAssessment.Models
{
    public abstract class Employee
    {
        public int id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string designation { get; set; }
        public   double basicpay { get; set; }
        public   double salary { get; set; }


        public abstract double GetSalaryInfo(double basicpayvalue);
        /// <summary>
        /// get list of employees 
        /// </summary>
        /// <returns></returns>
        public List<Employee> getEmployeeInfo() {

            List<Employee> lstemployee = new List<Employee>();
            lstemployee.Add(new TemporaryEmployee()
            {
                id = 1,
                Name = "raji",
                Age = 26,
                designation = "Devloper",
                basicpay = 2000,
                salary = 50000
            });
            lstemployee.Add(new TemporaryEmployee()
            {
                id = 2,
                Name = "rubon",
                Age = 23,
                designation = "Devloper",
                basicpay = 2000,
                salary = 70000
            });
            return lstemployee;
        }
        /// <summary>
        /// add each employee to database
        /// </summary>
        /// <param name="employee"></param>
        /// <returns></returns>
        public List<Employee> addEmployeeInfo(Employee employee) {

            List<Employee> lstemployee = new List<Employee>();
            lstemployee.Add(new TemporaryEmployee()
            {
                id = employee.id,
                Name = employee.Name,
                Age = employee.Age,
                designation =  employee.designation,
                basicpay = employee.basicpay,
                salary = employee.salary
            });
            return lstemployee;
        }


    }
}
