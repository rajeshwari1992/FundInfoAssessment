﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using FundInfoAssessment.Models;
using System.Text.Json;
namespace FundInfoAssessment.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }

    [ApiController]
    [Route("api/Data/")]
    public class DataController : ControllerBase
    {
        string result;

        public DataController()
        {
            result = string.Empty;
        }
        [Route("getEmpSalary")]
        [HttpGet]
        public string getEmpSalary(double basicpay)
        {
            TemporaryEmployee e = new TemporaryEmployee();
            PermanentEmployee p = new PermanentEmployee();

            result  = e.GetSalaryInfo(basicpay).ToString() + ":" + p.GetSalaryInfo(basicpay).ToString();

            return result;
        
        
        }

        [Route("getEmployeeInfo")]
        [HttpGet]
        public string getEmployeeInfo()
        {
            
            Employee e = new TemporaryEmployee();
            var employeeinfo = JsonSerializer.Serialize(e.getEmployeeInfo());
            return employeeinfo;








        }



    }
}
